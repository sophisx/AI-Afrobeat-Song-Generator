import gradio as gr
from TTS.api import TTS
from pydub import AudioSegment
import os

tts = TTS(model_name='tts_models/multilingual/multi-dataset/your_tts', progress_bar=False, gpu=False)

def generate_afrobeat_song(lyrics, audio_file, beat_file):
    vocal_path = 'vocals.wav'
    final_mix = 'afrobeat_song.wav'
    
    # Generate vocal using your voice sample
    tts.tts_to_file(text=lyrics, speaker_wav=audio_file, file_path=vocal_path)
    
    # Load vocal and beat
    vocals = AudioSegment.from_wav(vocal_path)
    beat = AudioSegment.from_file(beat_file)
    
    # Match lengths
    if len(vocals) > len(beat):
        vocals = vocals[:len(beat)]
    else:
        beat = beat[:len(vocals)]
    
    # Afrobeat timing: slight vocal delay
    vocals = AudioSegment.silent(duration=500) + vocals
    
    # Mix
    mixed = beat.overlay(vocals)
    mixed.export(final_mix, format='wav')
    return final_mix

app = gr.Interface(
    fn=generate_afrobeat_song,
    inputs=[
        gr.Textbox(label='Lyrics'),
        gr.Audio(type='filepath', label='Your Voice Sample (.wav)'),
        gr.Audio(type='filepath', label='Afrobeat Instrumental (.mp3 or .wav)')
    ],
    outputs=gr.Audio(type='filepath', label='Generated Afrobeat Song'),
    title='AI Afrobeat Song Generator'
)