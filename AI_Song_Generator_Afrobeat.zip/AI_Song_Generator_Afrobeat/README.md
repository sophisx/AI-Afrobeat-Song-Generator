# AI Afrobeat Song Generator
Generate Afrobeat-style songs from your voice and lyrics using Python and TTS.